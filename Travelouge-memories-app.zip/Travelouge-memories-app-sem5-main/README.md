# Travelouge-memories-app-sem5
In terminal

cd client

cd server 

In client

npm i

In server 

npm i

both side 

npm start
