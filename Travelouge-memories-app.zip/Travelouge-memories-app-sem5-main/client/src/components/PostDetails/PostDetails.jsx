import React from 'react';

const PostDetails = () => {
  console.log('POST DETAILS');
  
  return (
    <div>
        Post Details
    </div>
  )
};

export default PostDetails;